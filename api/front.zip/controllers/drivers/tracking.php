<?php


/**
 * Description of tracking
 *
 * namasteji.in/api/index.php?c=drivers/tracking&f=record;
 * 
 * @author admin
 */
class tracking {
    //put your code here
    
    public function record($params)
    {
        return $params;
    }
}
