<div class="text-center">
    <h1 class="text-center">Welcome to EMS</h1>
</div>