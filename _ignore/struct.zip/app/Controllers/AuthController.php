<?php

namespace App\Controllers;

//use Request;
//www.com/auth/login/dada/dad/ad/ada/da/
use Controller;
use App\Models\User;

class AuthController extends Controller {

    public function __construct()
    {
        //if already logged than redirct to home page
    }

    /**
     * Login
     * @return html
     */
    public function login()
    {
        if (\Auth::check())
        {
            redirect();
        }

        $error = FALSE;
        if ($_POST)
        {
            $validator = new \Validator();
            $validator->addRule('email', 'Email', 'required|email');
            $validator->addRule('password', 'Password', 'required');
            $valid = $validator->validate($_POST);
            if (!$valid)
            {
                $error = $validator->getErrorSummary();
            }
            else
            {
                $email = $_POST['email'];
                $password = $_POST['password'];
                $login = \Auth::login($email, $password);
                if ($login['status'])
                {
                    redirect();
                }
                $error[] = $login['message'];
            }
        }

        return view('auth.login', ['error' => $error]);
    }

    /**
     * /auth/logout
     * LogOut
     */
    public function logout()
    {
        if (\Auth::check())
        {
            \Auth::logout();
        }
        redirect();
    }

}
