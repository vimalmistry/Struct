<?php

return [


//        IF true its send notification on database error log
        'send_log' => FALSE,
        'send_log_mobile' => 9016913088,
        'send_log_email' => 'vimalmistry@namasteji.in'
];
