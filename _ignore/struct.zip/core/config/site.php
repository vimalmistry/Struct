<?php

return array(
    'siteName' => 'NamasteJi',
    'url' => '//localhost/struct',
    'default_controller' => 'home'
);
