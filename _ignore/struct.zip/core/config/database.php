<?php

return array(
    'host' => 'localhost',
    'port' => '',
    'user' => 'root',
    'password' => '',
    'name' => 'struct'
);

