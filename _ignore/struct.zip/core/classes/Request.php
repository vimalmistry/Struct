<?php

class Request {

    public static function init()
    {
        //get initial
    }

    /**
     * 
     * @param mix $key
     * @return mix
     */
    public static function get($key = null)
    {
        if (is_null($key))
        {
            return (object) $_GET;
        }

        if (isset($_GET[$key]))
        {
            return $_GET[$key];
        }

        return null;
    }

    /**
     * 
     * @param mix $key
     * @return mix
     */
    public static function post($key = null)
    {
        if (is_null($key))
        {
            return (object) $_POST;
        }

        if (isset($_POST[$key]))
        {
            return $_POST[$key];
        }

        return null;
    }

    /**
     * 
     * @param mix $key
     * @return mix
     */
    public static function server($key = null)
    {
        if (is_null($key))
        {
            return (object) $_SERVER;
        }

        if (isset($_SERVER[$key]))
        {
            return $_SERVER[$key];
        }

        return null;
    }

    /**
     * 
     * @param mix $key
     * @return mix
     */
    public static function cookie($key = null)
    {
        if (is_null($key))
        {
            return (object) $_COOKIE;
        }

        if (isset($_COOKIE[$key]))
        {
            return $_COOKIE[$key];
        }

        return null;
    }

    /**
     * 
     * @return string
     */
    public static function method()
    {
        return strtoupper(self::server('REQUEST_METHOD'));
    }

    /**
     * 
     * @return string
     */
    public static function url()
    {
        return self::server('REQUEST_URI');
    }

}
