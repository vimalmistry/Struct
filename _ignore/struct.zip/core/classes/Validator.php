<?php

use werx\Validation\Engine as ValidationEngine;

class Validator extends ValidationEngine {
    
}
